#Data Types

#String
"Hello"[4]
print("123" + "345")

#Integer
print(123 + 345)
123_456_345

#Float
3.14159

#Boolean
True
False
