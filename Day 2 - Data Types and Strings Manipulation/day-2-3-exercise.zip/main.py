# 🚨 Don't change the code below 👇
age = input("What is your current age? ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

int_age = int(age)
days_number = (365 * 90) - (int_age * 365)
weeks_number = (52 * 90) - (int_age * 52)
months_number = (12 * 90) - (int_age * 12)

outcome = f"You have {days_number} days, {weeks_number} weeks, and {months_number} months left."

print(outcome)






