import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

images = [rock, paper, scissors]

user_choice = input("What do you choose? Type 0 for Rock, 1 for Paper and 2 for Scissors.\n")
user_int = int(user_choice)

if user_int >= 3 or user_int < 0:
  print("You typed a wrong number. Try again.")
else:
  print(images[user_int])

  print("Computer chose:")

  computer_choice = random.randint(0, 2)
  print(images[computer_choice])

  
  if user_int >= 3 or user_int < 0:
    print("You typed a wrong number. Try again.")
  if user_int == computer_choice:
    print("Draw. Try again.")
  elif user_int == 0 and computer_choice == 2:
    print("You win.")
  elif computer_choice == 0 and user_int == 2:
    print("You lose.")
  elif computer_choice > user_int:
    print("You lose.")
  elif user_int > computer_choice:
    print("You win.")