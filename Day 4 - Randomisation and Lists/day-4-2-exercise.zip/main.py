import random
# Split string method
names_string = input("Give me everybody's names, separated by a comma. ")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

list_length = len(names)
random_number = random.randint(0, list_length - 1)

winner = names[random_number]

print(f"{winner} is going to buy the meal today.")


### 2nd way to solve the problem without using choice() function ###

# random_order = random.sample(names, len(names))
# winner = random_order[0]
# print(f"{winner} is going to buy a meal.")
