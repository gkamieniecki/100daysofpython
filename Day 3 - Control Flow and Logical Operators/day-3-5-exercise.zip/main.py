# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n ")
name2 = input("What is their name? \n ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇


name1_lowercase = name1.lower()
name2_lowercase = name2.lower()

t = (name1_lowercase.count("t") + name2_lowercase.count("t"))
r = (name1_lowercase.count("r") + name2_lowercase.count("r"))
u = (name1_lowercase.count("u") + name2_lowercase.count("u"))
e = (name1_lowercase.count("e") + name2_lowercase.count("e"))

l = (name1_lowercase.count("l") + name2_lowercase.count("l"))
o = (name1_lowercase.count("o") + name2_lowercase.count("o"))
v = (name1_lowercase.count("v") + name2_lowercase.count("v"))
e = (name1_lowercase.count("e") + name2_lowercase.count("e"))

true_total = t + r + u + e
love_total = l + o + v + e

true_love_total = str(true_total) + str(love_total)

final_score = int(true_love_total)

if final_score < 10 or final_score > 90:
  print(f"Your score is {final_score}, you go together like coke and mentos.")
elif final_score > 40 and final_score < 50:
  print(f"Your score is {final_score}, you are alright together.")
else:
  print(f"Your score is {final_score}.")
