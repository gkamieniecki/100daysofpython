#Write your code below this row 👇

even_sum = 0

for number in range(0, 101):
  if number % 2 == 0:
    even_sum += number

print(even_sum)