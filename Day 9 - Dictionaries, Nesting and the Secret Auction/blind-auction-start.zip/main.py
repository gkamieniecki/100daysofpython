from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo

print(logo)

bidders = {}

def find_winner(bids_record):
  highest_bid = 0
  winner = ""
  for bidder in bids_record:
    bid_value = (bids_record[bidder])
    if bid_value > highest_bid:
      highest_bid = bid_value
      winner = bidder
  print(f"The winner is {winner} with a bid of £{highest_bid}.")

repeat = False
while not repeat:
  name = input("What is your name?: ")
  bid = int(input("What is your bid?: £"))
  bidders[name] = bid
  ask_user = input('Are there any other bidders? Type "yes" or "no".\n')
  if ask_user == "yes":
    clear()
  elif ask_user == "no":
      repeat = True
      find_winner(bidders)
      

